import React from 'react'
import './index.css'
import Product1 from '../../assets/images/product1.jpeg'
import Product2 from '../../assets/images/product2.jpeg'
import Product3 from '../../assets/images/product3.jpeg'
import Product4 from '../../assets/images/product4.jpeg'


const OurProducts = () => {
  return (
    <div className="container py-5">

      {/* Section Header */}
      <div className="text-center mb-5">
        <h2 className="fw-bold">Our Products</h2>
        <p className="text-muted">
          A wide range of healthcare, hygiene, and lifestyle essentials
        </p>
      </div>

      <div className="row g-4">

        {/* Healthcare & Orthopedic */}
        <div className="col-md-6 col-lg-3">
          <div className="product-card">

            {/* Carousel */}
            <div
              id="healthcareCarousel"
              className="carousel slide product-carousel"
              data-bs-ride="carousel"
            >
              <div className="carousel-inner">
                <div className="carousel-item active">
                  <img src={Product1} className="d-block w-100" alt="" />
                </div>
                <div className="carousel-item">
                  <img src={Product2} className="d-block w-100" alt="" />
                </div>
                <div className="carousel-item">
                  <img src={Product3} className="d-block w-100" alt="" />
                </div>
              </div>
            </div>

            <h5 className="fw-bold mt-3">🧑‍⚕️ Healthcare & Orthopedic</h5>
            <ul className="list-unstyled text-muted">
              <li>Cervical collars & pillows</li>
              <li>Knee, elbow, wrist supports</li>
              <li>Abdominal & rib belts</li>
              <li>Hot & cold therapy kits</li>
              <li>Traction systems</li>
            </ul>

            <p className="product-note">
              📍 Sourced from trusted manufacturers with quality standards.
            </p>
          </div>
        </div>

        {/* Hygiene & Cotton */}
        <div className="col-md-6 col-lg-3">
          <div className="product-card">

            <div
              id="hygieneCarousel"
              className="carousel slide product-carousel"
              data-bs-ride="carousel"
            >
              <div className="carousel-inner">
                <div className="carousel-item active">
                  <img src={Product2} className="d-block w-100" alt="" />
                </div>
                <div className="carousel-item">
                  <img src="https://via.placeholder.com/300x180?text=Underpads" className="d-block w-100" alt="" />
                </div>
                <div className="carousel-item">
                  <img src="https://via.placeholder.com/300x180?text=Hygiene+Essentials" className="d-block w-100" alt="" />
                </div>
              </div>
            </div>

            <h5 className="fw-bold mt-3">🧼 Hygiene & Cotton Products</h5>
            <ul className="list-unstyled text-muted">
              <li>Cotton balls & buds</li>
              <li>Makeup pads</li>
              <li>Underpads</li>
              <li>Surgical cotton & absorbent wool</li>
              <li>N95 & surgical masks</li>
            </ul>

            <p className="product-note">
              📍 Premium quality with strict hygiene compliance.
            </p>
          </div>
        </div>

        {/* Medical Dressings */}
        <div className="col-md-6 col-lg-3">
          <div className="product-card">

            <div
              id="medicalCarousel"
              className="carousel slide product-carousel"
              data-bs-ride="carousel"
            >
              <div className="carousel-inner">
                <div className="carousel-item active">
                  <img src={Product3} className="d-block w-100" alt="" />
                </div>
                <div className="carousel-item">
                  <img src="https://via.placeholder.com/300x180?text=Gauze+Swabs" className="d-block w-100" alt="" />
                </div>
                <div className="carousel-item">
                  <img src="https://via.placeholder.com/300x180?text=Rehab+Tools" className="d-block w-100" alt="" />
                </div>
              </div>
            </div>

            <h5 className="fw-bold mt-3">🩹 Medical Dressings & Accessories</h5>
            <ul className="list-unstyled text-muted">
              <li>Gauze swabs</li>
              <li>Finger splints</li>
              <li>Fracture aids</li>
              <li>Gel & foot care products</li>
              <li>Rehabilitation tools</li>
            </ul>

            <p className="product-note">
              📍 Solutions for clinics, hospitals, and pharmacies.
            </p>
          </div>
        </div>

        {/* Apparel */}
        <div className="col-md-6 col-lg-3">
          <div className="product-card">

            <div
              id="apparelCarousel"
              className="carousel slide product-carousel"
              data-bs-ride="carousel"
            >
              <div className="carousel-inner">
                <div className="carousel-item active">
                  <img src={Product4} className="d-block w-100" alt="" />
                </div>
                <div className="carousel-item">
                  <img src="https://via.placeholder.com/300x180?text=Protective+Wear" className="d-block w-100" alt="" />
                </div>
                <div className="carousel-item">
                  <img src="https://via.placeholder.com/300x180?text=Comfort+Wear" className="d-block w-100" alt="" />
                </div>
              </div>
            </div>

            <h5 className="fw-bold mt-3">👕 Apparel & Protective Wear</h5>
            <ul className="list-unstyled text-muted">
              <li>Ladies & kids wear</li>
              <li>Hospital & safety garments</li>
              <li>Active & nightwear</li>
              <li>Comfort-focused fabric options</li>
            </ul>

            <p className="product-note">
              📍 Blending comfort with quality fabric options.
            </p>
          </div>
        </div>

      </div>

      {/* CTA */}
      <div className="text-center mt-5">
        <button className="btn btn-primary px-5 py-2">
          View Full Catalogue
        </button>
      </div>

    </div>
  )
}

export default OurProducts

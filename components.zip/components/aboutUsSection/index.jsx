import React from 'react'
import './index.css'

const AboutUs = () => {
    return (
        <div className="container py-5 about-section">

            {/* Section Header */}
            <div className="text-center mb-5">
                <h2 className="fw-bold">🧠 About Us</h2>
                <p className="text-muted">
                    Building trust in healthcare through quality and reliability
                </p>
            </div>

            {/* Who We Are */}
            <div className="row align-items-center mb-5">
                <div className="col-md-6">
                    <h4 className="fw-semibold mb-3">Who We Are</h4>
                    <p className="text-muted">
                        We are a leading manufacturer, distributor, and authorized dealer of
                        premium healthcare, hygiene, and rehabilitation products — serving
                        hospitals, retail chains, clinics, and distributors across India.
                    </p>
                    <p className="text-muted">
                        Founded with a vision to bring quality products under one roof, we blend
                        manufacturing expertise with carefully selected partnerships to ensure
                        consistent quality, reliability, and trust across all our offerings.
                    </p>

                </div>

                <div className="col-md-6">
                    <div className="about-highlight-box">
                        <h6 className="fw-bold">Why Choose Us?</h6>
                        <ul className="list-unstyled mt-3">
                            <li>✔ Authorized Brand Partnerships</li>
                            <li>✔ Quality-Assured Manufacturing</li>
                            <li>✔ Pan-India Distribution Network</li>
                            <li>✔ Trusted by Healthcare Professionals</li>
                        </ul>
                    </div>
                </div>
            </div>

            {/* Mission & Vision */}
            <div className="row g-4">
                <div className="col-md-6">
                    <div className="about-card">
                        <h5 className="fw-bold mb-2">Our Mission</h5>
                        <p className="text-muted">
                            To deliver high-quality, accessible, and affordable health support
                            products that improve patient comfort, care, and outcomes.
                        </p>
                    </div>
                </div>

                <div className="col-md-6">
                    <div className="about-card">
                        <h5 className="fw-bold mb-2">Our Vision</h5>
                        <p className="text-muted">
                            To become India’s most reliable healthcare product partner and
                            authorized supplier for medical and hygiene essentials.
                        </p>
                    </div>
                </div>
            </div>

        </div>
    )
}

export default AboutUs

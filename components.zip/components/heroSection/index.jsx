import React from 'react';
import SurgicalGroup from '../../assets/images/surgicalGroup.png';
import './index.css';

const HeroSection = () => {
  return (
    <section className="hero-section">
      <div className="hero-overlay">
        <div className="hero-content-wrapper">
          <div className="hero-content">
            <h1 className="hero-title">
              Find Your Perfect Tutor
            </h1>
            <p className="hero-text">
              Whether learning is for skills, career, or personal growth, we help you find
              the best tutors and resources for your needs.
            </p>
            <div className="hero-buttons">
              <button className="btn btn-primary">Explore Now</button>
              <button className="btn btn-outline-light">Book a Session</button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;

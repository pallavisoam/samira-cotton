import React from "react";
import { FaFacebookF, FaInstagram, FaWhatsapp } from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="bg-dark text-light pt-5 pb-3">
      <div className="container">
        <div className="row">
          {/* Contact Section */}
          <div className="col-md-4 mb-4">
            <h5 className="text-uppercase fw-bold mb-3">Contact Us</h5>
            <p className="mb-1">
              <strong>Phone:</strong> +91 98765 43210
            </p>
            <p className="mb-1">
              <strong>Email:</strong> info@yourcompany.com
            </p>
            <p className="mb-0">
              <strong>WhatsApp:</strong> +91 98765 43210
            </p>
          </div>

          {/* Address Section */}
          <div className="col-md-4 mb-4">
            <h5 className="text-uppercase fw-bold mb-3">Our Address</h5>
            <p className="mb-0">
              Wellness Distribution Pvt. Ltd. <br />
              123 Health Street, Sector 21 <br />
              Mumbai, Maharashtra, India
            </p>
          </div>

          {/* Social Media Section */}
          <div className="col-md-4 mb-4">
            <h5 className="text-uppercase fw-bold mb-3">Follow Us</h5>
            <div className="d-flex gap-3">
              <a
                href="https://wa.me/919876543210"
                target="_blank"
                rel="noopener noreferrer"
                className="text-light fs-4"
              >
                <FaWhatsapp />
              </a>
              <a
                href="https://www.facebook.com/yourpage"
                target="_blank"
                rel="noopener noreferrer"
                className="text-light fs-4"
              >
                <FaFacebookF />
              </a>
              <a
                href="https://www.instagram.com/yourpage"
                target="_blank"
                rel="noopener noreferrer"
                className="text-light fs-4"
              >
                <FaInstagram />
              </a>
            </div>
          </div>
        </div>

        {/* Footer Bottom */}
        <hr className="border-light" />
        <div className="text-center mt-3">
          <small>&copy; {new Date().getFullYear()} Wellness Distribution Pvt. Ltd. All rights reserved.</small>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

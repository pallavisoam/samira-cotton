import React from 'react'
import HeaderLogo from '../../assets/images/logo_img.svg'
import './index.css'

const Header = () => {
  return (
    <div className="d-flex justify-content-between align-items-center header-parent-div">
      
      {/* Left: Logo */}
      <div>
        <img
          src={HeaderLogo}
          alt="header"
          className="logo_header"
        />
      </div>

      {/* Right: Menu */}
      <div className="d-flex align-items-center gap-4">
        <p className="mb-0">Home</p>
        <p className="mb-0">About us</p>
        <p className="mb-0">Products</p>
        <p className="mb-0">Testimonials</p>
        <p className="mb-0">Contact Us</p>
      </div>

    </div>
  )
}

export default Header
